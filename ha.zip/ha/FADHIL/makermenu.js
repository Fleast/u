const makermenu = (prefix) => { 
	return ` 
╭───「 *CREATOR MENU* 」───
│
├➲ *${prefix}sticker*
├➲ *${prefix}quotemaker [tx/wtrmk/tema]*
├➲ *${prefix}nulis [nama/kelas/text]*
├➲ *${prefix}trigger [reply image]*
├➲ *${prefix}rip [reply image]*
├➲ *${prefix}wasted [reply image]*
├➲ *${prefix}cphlogo [Hanbei/Khansa]*
├➲ *${prefix}cglitch [Hanbei/Khansa]*
├➲ *${prefix}cpubg [Hanbei/Khansa]*
├➲ *${prefix}cml [Khansa/Hanbei]*
├➲ *${prefix}tahta [Hanbei]*
├➲ *${prefix}croman [Hanbei dan Khansa]*
├➲ *${prefix}cthunder [Hanbei]*
├➲ *${prefix}cbpink [Hanbei]*
├➲ *${prefix}cmwolf [Hanbei]*
├➲ *${prefix}csky [Hanbei]*
├➲ *${prefix}cwooden [Hanbei]*
├➲ *${prefix}cflower [Hanbei]*
├➲ *${prefix}clove [Hanbei]*
├➲ *${prefix}ccrossfire [Hanbei]*
├➲ *${prefix}cnaruto [Hanbei]*
├➲ *${prefix}cparty [Hanbei]*
├➲ *${prefix}cshadow [Hanbei]*
├➲ *${prefix}cminion [Hanbei]*
├➲ *${prefix}cneon [Hanbei]*
├➲ *${prefix}cneon2 [Hanbei]*
├➲ *${prefix}cneongreen [Hanbei]*
├➲ *${prefix}c3d [Hanbei]*
├➲ *${prefix}csky [Hanbei]*
├➲ *${prefix}tts [id Hanbei]*
├➲ *${prefix}ttp [Hanbei]*
├➲ *${prefix}slide [Hanbei]*
├➲ *${prefix}stiker*
├➲ *${prefix}gifstiker*
├➲ *${prefix}toimg*
├➲ *${prefix}img2url*
├➲ *${prefix}nobg*
├➲ *${prefix}tomp3*
├➲ *${prefix}ocr*
│
╰──────────────────────

	           *©Hanbei BOT*`
	}
exports.makermenu = makermenu