const help = (prefix, instagram, yt, name, pushname2, user, limitt) => { 
	return `

╭───────────────────
┃╭─────────────────
┃├➲ \`\`\`Hallo\`\`\`👋 *${pushname2}*
┃├➲ \`\`\`Limit Kamu :\`\`\` *${limitCounts}*
┃├➲ \`\`\`Verifikasi.   :\`\`\` *YES*
┃├➲ \`\`\`Premium.   :\`\`\` *NO*
┃├➲ \`\`\`Total Pengguna :\`\`\` *${user.length} User*
┃├➲ \`\`\`Total Donasi :\`\`\` *0%* 🙂
┃╰─────────────────
┃
┃╭───「 *LIST MENU* 」───
┃├❍ *${prefix}allmenu*
┃├❍ *${prefix}mediamenu*
┃├❍ *${prefix}creatormenu*
┃├❍ *${prefix}groupmenu*
┃├❍ *${prefix}makermenu*
┃├❍ *${prefix}funmenu*
┃├❍ *${prefix}nsfwmenu*
┃├❍ *${prefix}onwermenu*
┃╰─────────────────
┃
┃╭─────「 *ABOUT* 」───
┃├❍ *${prefix}info*
┃├❍ *${prefix}donasi*
┃├❍ *${prefix}owner*
┃├❍ *${prefix}speed*
┃├❍ *${prefix}daftar*
┃├❍ *${prefix}totaluser*
┃├❍ *${prefix}chatlist*
┃├❍ *${prefix}grouplist*
┃├❍ *${prefix}blocklist*
┃├❍ *${prefix}banlist*
┃├❍ *${prefix}bahasa*
┃╰─────────────────
╰────────────────────

         *©Hanbei BOT*`
}
exports.help = help