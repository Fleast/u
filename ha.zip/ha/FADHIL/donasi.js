const donasi = (Ig, name) => { 
	return `       
┏━━━━━━━━━━━━━━━━━━━━
┃          𝗗𝗢𝗡𝗔𝗦𝗜  
┣━━━━━━━━━━━━━━━━━━━━
┣━⊱ *DONASI SEIKHLASNYA:)* ❉⊰━━✿
┃  
┣━⊱ *DANA*
┣⊱ HUBUNGI OWNER AJA
┣━⊱ *PULSA*
┣⊱ HUBUNGI OWNER AJA
┃
┣━━━━━━━━━━━━━━━━━━━━
┃  *BOT BY ${name}*
┗━━━━━━━━━━━━━━━━━━━━
Note:
Jika Gamau Donasi Setidaknya Follow IG Ngab:D
Kalo Dah Donasi Silahkan Invit Di Group Kalian:)
Makasih:)


`
}

exports.donasi = donasi